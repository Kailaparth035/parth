import {
  AddEditArticalRequest,
  AddEditArticalResponse,
} from '../Action/AddArticalAction';

export default {
  AddEditArticalRequest: AddEditArticalRequest,
  AddEditArticalResponse: AddEditArticalResponse,
};
