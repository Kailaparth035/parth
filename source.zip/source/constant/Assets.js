const filepath = '../assets/Icon/';

export default {
  Angry: require(filepath + '/good-service.png'),
};
