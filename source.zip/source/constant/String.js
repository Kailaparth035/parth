class String {
  static login = 'Login';
  static signUp = 'SignUp';
}
export default String;
