export default {
  Login: 'Login',
  SignUp: 'SignUp',
};
