export default {
  // //Bold
  Ubuntu_Bold: 'Ubuntu-Bold',
  Ubuntu_BoldItalic: 'Ubuntu-BoldItalic',

  // //Light
  Ubuntu_Light: 'Ubuntu-Light',
  Ubuntu_LightItalic: 'Ubuntu-LightItalic',

  // //Medium
  Ubuntu_Medium: 'Ubuntu-Medium',
  Ubuntu_MediumItalic: 'Ubuntu-MediumItalic',

  // //Regular
  Ubuntu_Regular: 'Ubuntu-Regular',
  Ubuntu_RegularItalic: 'Ubuntu-RegularItalic',
};
