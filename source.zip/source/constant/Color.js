export default {
  White: '#FFFFFF',
  Black: '#000000',
};
